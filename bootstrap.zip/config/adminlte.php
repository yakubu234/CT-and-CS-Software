<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Title
    |--------------------------------------------------------------------------
    |
    | Here you can change the default title of your admin panel.
    |
    | For detailed instructions you can look the title section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'title' => 'Oreoluwapo CT&CU',
    'title_prefix' => '',
    'title_postfix' => '',

    /*
    |--------------------------------------------------------------------------
    | Favicon
    |--------------------------------------------------------------------------
    |
    | Here you can activate the favicon.
    |
    | For detailed instructions you can look the favicon section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'use_ico_only' => false,
    'use_full_favicon' => false,

    /*
    |--------------------------------------------------------------------------
    | Google Fonts
    |--------------------------------------------------------------------------
    |
    | Here you can allow or not the use of external google fonts. Disabling the
    | google fonts may be useful if your admin panel internet access is
    | restricted somehow.
    |
    | For detailed instructions you can look the google fonts section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'google_fonts' => [
        'allowed' => true,
    ],

    /*
    |--------------------------------------------------------------------------
    | Admin Panel Logo
    |--------------------------------------------------------------------------
    |
    | Here you can change the logo of your admin panel.
    |
    | For detailed instructions you can look the logo section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'logo' => '<b>Oreoluwapo</b> CT & CU',
    'logo_img' => 'vendor/adminlte/dist/img/AdminLTELogo.png',
    'logo_img_class' => 'brand-image img-circle elevation-3',
    'logo_img_xl' => null,
    'logo_img_xl_class' => 'brand-image-xs',
    'logo_img_alt' => 'Oreoluwapo CT&CU Logo',

    /*
    |--------------------------------------------------------------------------
    | Authentication Logo
    |--------------------------------------------------------------------------
    |
    | Here you can setup an alternative logo to use on your login and register
    | screens. When disabled, the admin panel logo will be used instead.
    |
    | For detailed instructions you can look the auth logo section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'auth_logo' => [
        'enabled' => false,
        'img' => [
            'path' => 'vendor/adminlte/dist/img/AdminLTELogo.png',
            'alt' => 'Oreoluwapo CT&CU Auth Logo',
            'class' => '',
            'width' => 50,
            'height' => 50,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Preloader Animation
    |--------------------------------------------------------------------------
    |
    | Here you can change the preloader animation configuration. Currently, two
    | modes are supported: 'fullscreen' for a fullscreen preloader animation
    | and 'cwrapper' to attach the preloader animation into the content-wrapper
    | element and avoid overlapping it with the sidebars and the top navbar.
    |
    | For detailed instructions you can look the preloader section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'preloader' => [
        'enabled' => true,
        'mode' => 'fullscreen',
        'img' => [
            'path' => 'vendor/adminlte/dist/img/AdminLTELogo.png',
            'alt' => 'Oreoluwapo CT&CU Preloader Image',
            'effect' => 'animation__shake',
            'width' => 60,
            'height' => 60,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | User Menu
    |--------------------------------------------------------------------------
    |
    | Here you can activate and change the user menu.
    |
    | For detailed instructions you can look the user menu section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'usermenu_enabled' => true,
    'usermenu_header' => false,
    'usermenu_header_class' => 'bg-primary',
    'usermenu_image' => false,
    'usermenu_desc' => false,
    'usermenu_profile_url' => false,

    /*
    |--------------------------------------------------------------------------
    | Layout
    |--------------------------------------------------------------------------
    |
    | Here we change the layout of your admin panel.
    |
    | For detailed instructions you can look the layout section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Layout-and-Styling-Configuration
    |
    */

    'layout_topnav' => null,
    'layout_boxed' => null,
    'layout_fixed_sidebar' => null,
    'layout_fixed_navbar' => null,
    'layout_fixed_footer' => null,
    'layout_dark_mode' => null,

    /*
    |--------------------------------------------------------------------------
    | Authentication Views Classes
    |--------------------------------------------------------------------------
    |
    | Here you can change the look and behavior of the authentication views.
    |
    | For detailed instructions you can look the auth classes section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Layout-and-Styling-Configuration
    |
    */

    'classes_auth_card' => 'card-outline card-primary',
    'classes_auth_header' => '',
    'classes_auth_body' => '',
    'classes_auth_footer' => '',
    'classes_auth_icon' => '',
    'classes_auth_btn' => 'btn-flat btn-primary',

    /*
    |--------------------------------------------------------------------------
    | Admin Panel Classes
    |--------------------------------------------------------------------------
    |
    | Here you can change the look and behavior of the admin panel.
    |
    | For detailed instructions you can look the admin panel classes here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Layout-and-Styling-Configuration
    |
    */

    'classes_body' => '',
    'classes_brand' => '',
    'classes_brand_text' => '',
    'classes_content_wrapper' => '',
    'classes_content_header' => '',
    'classes_content' => '',
    'classes_sidebar' => 'sidebar-dark-primary elevation-4',
    'classes_sidebar_nav' => '',
    'classes_topnav' => 'navbar-white navbar-light',
    'classes_topnav_nav' => 'navbar-expand',
    'classes_topnav_container' => 'container',

    /*
    |--------------------------------------------------------------------------
    | Sidebar
    |--------------------------------------------------------------------------
    |
    | Here we can modify the sidebar of the admin panel.
    |
    | For detailed instructions you can look the sidebar section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Layout-and-Styling-Configuration
    |
    */

    'sidebar_mini' => 'lg',
    'sidebar_collapse' => false,
    'sidebar_collapse_auto_size' => false,
    'sidebar_collapse_remember' => false,
    'sidebar_collapse_remember_no_transition' => true,
    'sidebar_scrollbar_theme' => 'os-theme-light',
    'sidebar_scrollbar_auto_hide' => 'l',
    'sidebar_nav_accordion' => true,
    'sidebar_nav_animation_speed' => 300,

    /*
    |--------------------------------------------------------------------------
    | Control Sidebar (Right Sidebar)
    |--------------------------------------------------------------------------
    |
    | Here we can modify the right sidebar aka control sidebar of the admin panel.
    |
    | For detailed instructions you can look the right sidebar section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Layout-and-Styling-Configuration
    |
    */

    'right_sidebar' => false,
    'right_sidebar_icon' => 'fas fa-cogs',
    'right_sidebar_theme' => 'dark',
    'right_sidebar_slide' => true,
    'right_sidebar_push' => true,
    'right_sidebar_scrollbar_theme' => 'os-theme-light',
    'right_sidebar_scrollbar_auto_hide' => 'l',

    /*
    |--------------------------------------------------------------------------
    | URLs
    |--------------------------------------------------------------------------
    |
    | Here we can modify the url settings of the admin panel.
    |
    | For detailed instructions you can look the urls section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'use_route_url' => false,
    'dashboard_url' => 'home',
    'logout_url' => 'logout',
    'login_url' => 'login',
    'register_url' => 'register',
    'password_reset_url' => 'password/reset',
    'password_email_url' => 'password/email',
    'profile_url' => false,
    'disable_darkmode_routes' => false,

    /*
    |--------------------------------------------------------------------------
    | Laravel Asset Bundling
    |--------------------------------------------------------------------------
    |
    | Here we can enable the Laravel Asset Bundling option for the admin panel.
    | Currently, the next modes are supported: 'mix', 'vite' and 'vite_js_only'.
    | When using 'vite_js_only', it's expected that your CSS is imported using
    | JavaScript. Typically, in your application's 'resources/js/app.js' file.
    | If you are not using any of these, leave it as 'false'.
    |
    | For detailed instructions you can look the asset bundling section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Other-Configuration
    |
    */

    'laravel_asset_bundling' => false,
    'laravel_css_path' => 'css/app.css',
    'laravel_js_path' => 'js/app.js',

    /*
    |--------------------------------------------------------------------------
    | Menu Items
    |--------------------------------------------------------------------------
    |
    | Here we can modify the sidebar/top navigation of the admin panel.
    |
    | For detailed instructions you can look here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Menu-Configuration
    |
    */

    'menu' => [
        [
            'text' => 'Dashboard',
            'url' => 'dashboard',
            'icon' => 'fas fa-tachometer-alt',
            'active' => ['dashboard'],
            'permission' => 'dashboard.view',
        ],
        [
            'text' => 'Accounts',
            'icon' => 'fas fa-landmark',
            'permissions' => ['accounts.view', 'accounts.manage'],
            'submenu' => [
                [
                    'text' => 'All accounts',
                    'url' => 'accounts',
                    'icon' => 'far fa-circle',
                    'active' => ['accounts', 'accounts/*'],
                    'permissions' => ['accounts.view', 'accounts.manage'],
                ],
                [
                    'text' => 'Inactive accounts',
                    'url' => 'accounts/inactive',
                    'icon' => 'far fa-circle',
                    'active' => ['accounts/inactive'],
                    'permissions' => ['accounts.view', 'accounts.manage'],
                ],
                [
                    'text' => 'Account types',
                    'url' => 'account-types',
                    'icon' => 'far fa-circle',
                    'active' => ['account-types', 'account-types/*'],
                    'permissions' => ['accounts.view', 'accounts.manage'],
                ],
            ],
        ],
        [
            'text' => 'Switch branch',
            'url' => 'branches/switch',
            'icon' => 'fas fa-code-branch',
            'active' => ['branches/switch'],
            'permissions' => ['branches.view', 'branches.manage'],
        ],
        [
            'text' => 'Loans',
            'icon' => 'fas fa-folder-open',
            'permissions' => ['loans.view', 'loans.manage'],
            'submenu' => [
                [
                    'text' => 'All loans',
                    'url' => 'loans',
                    'icon' => 'fas fa-list',
                    'active' => ['loans', 'loans/*'],
                    'permissions' => ['loans.view', 'loans.manage'],
                ],
                [
                    'text' => 'Pending loans',
                    'url' => 'loans/pending',
                    'icon' => 'fas fa-hourglass-half',
                    'active' => ['loans/pending'],
                    'permissions' => ['loans.view', 'loans.manage'],
                ],
                [
                    'text' => 'Active loans',
                    'url' => 'loans/active',
                    'icon' => 'fas fa-bolt',
                    'active' => ['loans/active'],
                    'permissions' => ['loans.view', 'loans.manage'],
                ],
                [
                    'text' => 'Declined loans',
                    'url' => 'loans/declined',
                    'icon' => 'fas fa-ban',
                    'active' => ['loans/declined'],
                    'permissions' => ['loans.view', 'loans.manage'],
                ],
                [
                    'text' => 'Custom fields',
                    'url' => 'loans/custom-fields',
                    'icon' => 'fas fa-sliders-h',
                    'active' => ['loans/custom-fields'],
                    'permissions' => ['loans.view', 'loans.manage'],
                ],
            ],
        ],
        [
            'text' => 'Loan payments',
            'url' => 'loan-payments',
            'icon' => 'fas fa-receipt',
            'active' => ['loan-payments', 'loan-payments/*'],
            'permissions' => ['loan-payments.view', 'loan-payments.manage'],
        ],
        [
            'text' => 'Branches',
            'url' => 'branches',
            'icon' => 'fas fa-building',
            'active' => ['branches', 'branches/*'],
            'permissions' => ['branches.view', 'branches.manage'],
        ],
        [
            'text' => 'Income & Expenses',
            'icon' => 'fas fa-wallet',
            'permissions' => ['income-expenses.view', 'income-expenses.manage'],
            'submenu' => [
                [
                    'text' => 'All inc & exp',
                    'url' => 'income-expenses',
                    'icon' => 'far fa-circle',
                    'active' => ['income-expenses', 'income-expenses/*'],
                    'permissions' => ['income-expenses.view', 'income-expenses.manage'],
                ],
                [
                    'text' => 'Expense category',
                    'url' => 'expense-categories',
                    'icon' => 'far fa-circle',
                    'active' => ['expense-categories', 'expense-categories/*'],
                    'permissions' => ['income-expenses.view', 'income-expenses.manage'],
                ],
            ],
        ],
        [
            'text' => 'Members',
            'icon' => 'fas fa-users',
            'permissions' => ['members.view', 'members.manage'],
            'submenu' => [
                [
                    'text' => 'View members',
                    'url' => 'members',
                    'icon' => 'far fa-circle',
                    'active' => ['members', 'members/*'],
                    'permissions' => ['members.view', 'members.manage'],
                ],
                [
                    'text' => 'Custom fields',
                    'url' => 'members/custom-fields',
                    'icon' => 'far fa-circle',
                    'active' => ['members/custom-fields'],
                    'permissions' => ['members.view', 'members.manage'],
                ],
            ],
        ],
        [
            'text' => 'Blog',
            'url' => 'blog',
            'icon' => 'fas fa-blog',
            'active' => ['blog', 'blog/*'],
            'permissions' => ['blog.view', 'blog.manage'],
        ],
        [
            'text' => 'Bulk sms',
            'icon' => 'fas fa-comments',
            'permissions' => ['sms.view', 'sms.manage'],
            'submenu' => [
                [
                    'text' => 'SMS Settings',
                    'url' => 'bulk-sms/settings',
                    'icon' => 'fas fa-cogs',
                    'active' => ['bulk-sms/settings'],
                    'permissions' => ['sms.view', 'sms.manage'],
                ],
                [
                    'text' => 'SMS Templates',
                    'url' => 'bulk-sms/templates',
                    'icon' => 'fas fa-file-alt',
                    'active' => ['bulk-sms/templates', 'bulk-sms/templates/*'],
                    'permissions' => ['sms.view', 'sms.manage'],
                ],
                [
                    'text' => 'SMS Campaigns',
                    'url' => 'bulk-sms/campaigns',
                    'icon' => 'fas fa-bullhorn',
                    'active' => ['bulk-sms/campaigns', 'bulk-sms/campaigns/*'],
                    'permissions' => ['sms.view', 'sms.manage'],
                ],
                [
                    'text' => 'SMS Automations',
                    'url' => 'bulk-sms/automations',
                    'icon' => 'fas fa-magic',
                    'active' => ['bulk-sms/automations', 'bulk-sms/automations/*'],
                    'permissions' => ['sms.view', 'sms.manage'],
                ],
                [
                    'text' => 'SMS Logs',
                    'url' => 'bulk-sms/logs',
                    'icon' => 'fas fa-history',
                    'active' => ['bulk-sms/logs', 'bulk-sms/logs/*'],
                    'permissions' => ['sms.view', 'sms.manage'],
                ],
            ],
        ],
        [
            'text' => 'Transaction',
            'icon' => 'fas fa-exchange-alt',
            'permissions' => ['transactions.view', 'transactions.manage'],
            'submenu' => [
                [
                    'text' => 'All transaction',
                    'url' => 'transactions',
                    'icon' => 'far fa-circle',
                    'active' => ['transactions', 'transactions/*'],
                    'permissions' => ['transactions.view', 'transactions.manage'],
                ],
                [
                    'text' => 'Transaction Category',
                    'url' => 'transaction-categories',
                    'icon' => 'far fa-circle',
                    'active' => ['transaction-categories', 'transaction-categories/*'],
                    'permissions' => ['transactions.view', 'transactions.manage'],
                ],
            ],
        ],
        [
            'text' => 'Reports',
            'icon' => 'fas fa-chart-line',
            'permissions' => ['reports.view', 'reports.manage'],
            'submenu' => [
                [
                    'text' => 'Member balance',
                    'url' => 'reports/member-balance',
                    'icon' => 'far fa-circle',
                    'active' => ['reports/member-balance'],
                    'permissions' => ['reports.view', 'reports.manage'],
                ],
                [
                    'text' => 'Loan Report',
                    'url' => 'reports/loan-report',
                    'icon' => 'far fa-circle',
                    'active' => ['reports/loan-report'],
                    'permissions' => ['reports.view', 'reports.manage'],
                ],
                [
                    'text' => 'Loan Due Report',
                    'url' => 'reports/loan-due-report',
                    'icon' => 'far fa-circle',
                    'active' => ['reports/loan-due-report'],
                    'permissions' => ['reports.view', 'reports.manage'],
                ],
                [
                    'text' => 'Soc. Ledger Report',
                    'url' => 'reports/soc-ledger-report',
                    'icon' => 'far fa-circle',
                    'active' => ['reports/soc-ledger-report'],
                    'permissions' => ['reports.view', 'reports.manage'],
                ],
                [
                    'text' => 'Inc & Expense Report',
                    'url' => 'reports/income-expense-report',
                    'icon' => 'far fa-circle',
                    'active' => ['reports/income-expense-report'],
                    'permissions' => ['reports.view', 'reports.manage'],
                ],
                [
                    'text' => 'Interest Report',
                    'url' => 'reports/interest-report',
                    'icon' => 'far fa-circle',
                    'active' => ['reports/interest-report'],
                    'permissions' => ['reports.view', 'reports.manage'],
                ],
                [
                    'text' => 'Society Report',
                    'url' => 'reports/society-report',
                    'icon' => 'far fa-circle',
                    'active' => ['reports/society-report'],
                    'permissions' => ['reports.view', 'reports.manage'],
                ],
            ],
        ],
        [
            'text' => 'User management',
            'icon' => 'fas fa-user-shield',
            'permissions' => ['users.view', 'users.manage', 'roles.view', 'roles.manage'],
            'submenu' => [
                [
                    'text' => 'Admin users',
                    'url' => 'users',
                    'icon' => 'far fa-circle',
                    'active' => ['users', 'users/*'],
                    'permissions' => ['users.view', 'users.manage'],
                ],
                [
                    'text' => 'Admin roles',
                    'url' => 'user-roles',
                    'icon' => 'far fa-circle',
                    'active' => ['user-roles', 'user-roles/*'],
                    'permissions' => ['roles.view', 'roles.manage'],
                ],
                [
                    'text' => 'Exco roles',
                    'url' => 'exco-roles',
                    'icon' => 'far fa-circle',
                    'active' => ['exco-roles', 'exco-roles/*'],
                    'permissions' => ['roles.view', 'roles.manage'],
                ],
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Menu Filters
    |--------------------------------------------------------------------------
    |
    | Here we can modify the menu filters of the admin panel.
    |
    | For detailed instructions you can look the menu filters section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Menu-Configuration
    |
    */

    'filters' => [
        JeroenNoten\LaravelAdminLte\Menu\Filters\GateFilter::class,
        JeroenNoten\LaravelAdminLte\Menu\Filters\HrefFilter::class,
        JeroenNoten\LaravelAdminLte\Menu\Filters\SearchFilter::class,
        JeroenNoten\LaravelAdminLte\Menu\Filters\ActiveFilter::class,
        JeroenNoten\LaravelAdminLte\Menu\Filters\ClassesFilter::class,
        JeroenNoten\LaravelAdminLte\Menu\Filters\LangFilter::class,
        JeroenNoten\LaravelAdminLte\Menu\Filters\DataFilter::class,
    ],

    /*
    |--------------------------------------------------------------------------
    | Plugins Initialization
    |--------------------------------------------------------------------------
    |
    | Here we can modify the plugins used inside the admin panel.
    |
    | For detailed instructions you can look the plugins section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Plugins-Configuration
    |
    */

    'plugins' => [
        'Datatables' => [
            'active' => false,
            'files' => [
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js',
                ],
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js',
                ],
                [
                    'type' => 'css',
                    'asset' => false,
                    'location' => '//cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css',
                ],
            ],
        ],
        'Select2' => [
            'active' => false,
            'files' => [
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js',
                ],
                [
                    'type' => 'css',
                    'asset' => false,
                    'location' => '//cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.css',
                ],
            ],
        ],
        'Chartjs' => [
            'active' => false,
            'files' => [
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.0/Chart.bundle.min.js',
                ],
            ],
        ],
        'Sweetalert2' => [
            'active' => false,
            'files' => [
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdn.jsdelivr.net/npm/sweetalert2@8',
                ],
            ],
        ],
        'Pace' => [
            'active' => false,
            'files' => [
                [
                    'type' => 'css',
                    'asset' => false,
                    'location' => '//cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/themes/blue/pace-theme-center-radar.min.css',
                ],
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/pace.min.js',
                ],
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | IFrame
    |--------------------------------------------------------------------------
    |
    | Here we change the IFrame mode configuration. Note these changes will
    | only apply to the view that extends and enable the IFrame mode.
    |
    | For detailed instructions you can look the iframe mode section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/IFrame-Mode-Configuration
    |
    */

    'iframe' => [
        'default_tab' => [
            'url' => null,
            'title' => null,
        ],
        'buttons' => [
            'close' => true,
            'close_all' => true,
            'close_all_other' => true,
            'scroll_left' => true,
            'scroll_right' => true,
            'fullscreen' => true,
        ],
        'options' => [
            'loading_screen' => 1000,
            'auto_show_new_tab' => true,
            'use_navbar_items' => true,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Livewire
    |--------------------------------------------------------------------------
    |
    | Here we can enable the Livewire support.
    |
    | For detailed instructions you can look the livewire here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Other-Configuration
    |
    */

    'livewire' => false,
];
