<?php

namespace App\Http\Requests;

use App\Models\Designation;
use App\Support\PermissionRegistry;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;

class StoreRoleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => [
                'required',
                'string',
                'max:50',
                Rule::unique('roles', 'name'),
                function (string $attribute, mixed $value, \Closure $fail): void {
                    $slug = Str::slug((string) $value);

                    if ($slug !== '' && Designation::query()->where('slug', $slug)->exists()) {
                        $fail('That name is already reserved for an exco role/designation.');
                    }
                },
            ],
            'description' => ['nullable', 'string'],
            'permissions' => ['required', 'array', 'min:1'],
            'permissions.*' => ['string', Rule::in(PermissionRegistry::all())],
        ];
    }
}
